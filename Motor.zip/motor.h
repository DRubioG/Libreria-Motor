class Motor{
  private:
    int _enA,_enB, _in1, _in2, _in3, _in4;

  public:
    Motor(int, int, int, int, int, int);
    void Configuration();
    void Adelante();
    void Parar();
    void Derecha();
    void Izquierda();
    void Atras();
    void Giro();
    void GiroOp();
};
